<?php
class Conexionbasedatos 
{   
    public $server;
    public $usuario;
    public $contraseña;
    public $basedatos;
    public $conn;
    public function __construct()    {
        $this->server = "localhost";
        $this->usuario = "mpmdmiia_appliedmemory";
        $this->contrasena = "yolindo123*";
        $this->basedatos = "mpmdmiia_appliedmemoryweb";
    }
    function Conect()
    {
        $connect = mysqli_connect($this->server,$this->usuario,$this->contrasena,$this->basedatos);
        $this->conn=$connect;
        return $this->conn;
    }
}
?>