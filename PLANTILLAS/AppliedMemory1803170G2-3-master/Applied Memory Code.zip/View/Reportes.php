<?php 
include_once('../config.php');
include_once("../Model/user_session.php");
$userSession = new UserSession(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Css/Reporte.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
</head>
<body >
    <div id="body">
    <?php
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
                require_once("navbarA.php");
            break;
            case 2:
                require_once("navbarL.php");
            break;
            case 3:
                header("location: index");
            break;
        }
    }else{
        header("location: Login");
    }
    ?>
    <main class="Treportes container mt-4 ">
        <div class="container header row">
            <h5 class="col-3">REPORTES</h5>
            <div  class="col-6">
                <div><input id="Buscar" class="mr-2" placeholder="BUSCAR REPORTE" type="text"><img src="Css/Img/tools-and-utensils.png" alt=""></div>
            </div>
            <div class="col-3">
                <select  name="" id="OPCION">
                    <option hidden selected value="0">BUCAR POR</option>
                    <option value="1">ID</option>
                    <option value="2">TIPO COMPONENTE</option>
                    <option value="3">AMBIENTE</option>
                    <option value="4">FECHA</option>
                </select>
            </div>
        </div>
        <div class="container Reportes mt-5"> 
            <table>
            <tr style="text-align:center" class="lt">
                <td style="width:10%" class="l">ID REPORTE</td>
                <td style="width:20%" class="l">ESTADO REPORTE</td>
                <td style="width:20%" class="l">INSTRUCTOR</td>
                <td style="width:20%" class="l">TIPO COMPONENTE</td>
                <td style="width:10%" class="l">AMBIENTE</td>
                <td style="width:20%" class="l">FECHA</td>
            </tr>
            </table>
            <table id="Actualizar">
                <?php
                include_once ("../Model/dao.php");
                $dao = new chat();
                $r = $dao->Chats();
                $dao1 = new ReporteD();
                $r1 = $dao1->VerTodosReportesID('');
                while($ver=mysqli_fetch_row($r1)){
                    echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                    <td style="width:10%"  class="lP">'.$ver[0].'</td>
                    <td style="width:20%"  class="lP">'.$ver[5].'</td>
                    <td style="width:20%">'.$ver[6].'</td>
                    <td style="width:20%">'.$ver[1].'</td>
                    <td style="width:10%">'.$ver[2].'</td>
                    <td style="width:20%">'.$ver[3].'</td>
                    </tr>';
                }
                ?>
        </table>
        </div>
    </main>
    <?php include_once("footer.php") ?>
        </div>
    <div id="mensajeria" class="mensajeria animated faster">
    <div class="padding">
            <div class="Chat ml-4">
                    <div class="header">
                        <header > <br> / / </header>
                        <button onClick="Cancelar2()" class="btn btn-danger">VOLVER</button>
                    </div>
                    <div id="MostrarChat" class="main mt-1 mb-1">
                    
                    </div>
                    <div style="bakcground-color:white" class="footers">
                    <input id="mensaje" class="text" type="text"><img id="enviar" onClick="name()" src="Css/Img/communications.png" alt="">
                    </div>
            </div>
</div>
    </div>
    <main id="Resumen" class="Resumen animated faster">
    </main>
    <?php include_once("footer.php") ?>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script type="text/javascript">
function Solucionar($id){
    bootbox.confirm({
    title: "Confimar Solucion",
    message: "Estas seguro de empezar el proceso de solucion del reporte #" + $id,
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> Cancelar'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> Confirmar'
        }
    },
    callback: function (result) {
        if(result==true){
            
        }
    }
});

}
 function VerReporte($id){
        $.ajax({
        type:"POST",
        url:"Controller/VerReporte.php",
        data: {'IdMensaje': $id,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#Resumen').html(r);
            const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success ',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
            })
            if(document.getElementById('solucionar-chat').value==1){
                Swal.fire({
                html: r,
                showCancelButton: true,
                confirmButtonText: 'SOLUCIONADO',
                width: '50%',
                cancelButtonText: 'VER CHAT',
                showCloseButton: true,
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    Swal.fire({
                    html: "CONFIMAR",
                    showCancelButton: true,
                    confirmButtonText: 'Confirmar',
                    cancelButtonText: 'Cancelar',
                    reverseButtons: true
                    }).then((result) => {
                    if (result.value) {
                        $.ajax({
                        type:"POST",
                        url:"Controller/SolucionReportes.php",
                        data: {'Id': $id,'Estado': 1},
                        success:function(r){
                           
                        }});
                        $.ajax({
                        type:"POST",
                        url:"Controller/Notificaciones.php",
                        data: {'Id': $id,'Mensaje': 'Tu reporte #'+$id+' esta solucionado'},
                        success:function(r){
                        }});
                        swalWithBootstrapButtons.fire(
                            'SOLUCIONADO',
                            'El reporte #'+$id+' se ecuentra solucionado felicidades',
                            'success'
                        )
                    }
                    });
                }else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    cambio($id)
                }
                });
            }
            if(document.getElementById('solucionar-chat').value==2){
                Swal.fire({
                html: r,
                showCancelButton: true,
                confirmButtonText: 'Solucionar',
                cancelButtonText: 'Cancelar',
                width: '50%',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    Swal.fire({
                    html: "CONFIMAR",
                    showCancelButton: true,
                    confirmButtonText: 'Solucionar',
                    cancelButtonText: 'Cancelar',
                    reverseButtons: true
                    }).then((result) => {
                    if (result.value) {
                        $.ajax({
                        type:"POST",
                        url:"Controller/SolucionReportes.php",
                        data: {'Id': $id,'Estado': 3},
                        success:function(r){
                            
                        }});
                        $.ajax({
                        type:"POST",
                        url:"Controller/Notificaciones.php",
                        data: {'Id': $id,'Mensaje': 'Tu reporte #'+$id+' esta en solucion'},
                        success:function(r){
                        }});
                        swalWithBootstrapButtons.fire(
                            'En solucion',
                            'El reporte #'+$id+' se ecuentra en solucion',
                            'success'
                        )
                    }
                    });
                }
                });
            }
            if(document.getElementById('solucionar-chat').value==3){
                Swal.fire({
                html: r,
                showCancelButton: true,
                confirmButtonText: 'VER CHAT',
                width: '50%',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    cambio($id)
                }
                });
            }
        }});
    }
var va;
function cambio($cc){
    clearInterval(va);
    recargarLista($cc);
    document.getElementById('mensajeria').style.display="block";
    document.getElementById('mensajeria').classList.remove("fadeOutUp");
    document.getElementById('mensajeria').classList.add("fadeInDown");
}
function recargarLista($cc){
    $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/ajax.php",
        data: {'chatAver': $cc,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#MostrarChat').html(r);
        }});
    va = setInterval(function(){
        console.log("si");
        $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/ajax.php",
        data: {'chatAver': $cc,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#MostrarChat').html(r);
        }});
    }, 2000)}
function Cancelar2(){
    clearInterval(va);
    document.getElementById('mensajeria').classList.remove("fadeInDown");
    document.getElementById('mensajeria').classList.add("fadeOutUp");
    setTimeout("Quitar2()",400);
    var Opacidad = document.getElementById("body");
    Opacidad.style.opacity="1";
    var mostrar = document.getElementById("Resumen");
}
function Quitar2(){
        document.getElementById('mensajeria').style.display="none"
    }
</script>
<script>
$("#enviar").click(function(){
    name();
});
function verDatos(){
    $.ajax({
    type:"POST",
        url:"<?php echo SERVERURL;?>Controller/VerDatos.php",
        data: {'VerRe': $('#Buscar').val(),'OPCION': $('#OPCION').val()},
        success:function(r){
            $('#Actualizar').html(r);
        }});
}
$("#Buscar").keydown(function () {
    setTimeout("verDatos()",40);
});
function name() {
    $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/EnviarMensaje.php",
        data: {'mensaje': $('#mensaje').val(),'id': $('#chat').val(),'CC': <?php echo $_SESSION["user"]; ?>}
    });
    $('#mensaje').val('');
}
$('#mensaje').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
        name();
    }
});
<?php if(isset($_GET["x"])){
    $id = $_GET["x"];
    echo "VerReporte('".$id."')";
} ?>
</script>
