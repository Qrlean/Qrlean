<?php 
    include_once("../Model/user_session.php");
    $userSession = new UserSession(); 
    include_once('../config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Activos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/Activos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
</head>
<body >
    <div id="body" >
<?php
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
                require_once("navbarA.php");
            break;
            case 2:
                require_once("navbarL.php");
            break;
            case 3:
                header("location: index");
            break;
        }
    }else{
        header("location: Login");
    }
    ?>
    <main class="Activos container mt-4">
        <header class="row container" style="background-color:#292929;justify-content: center;padding:20px;padding-bottom:15px">
            <div class="col-3">
            <span style='border:none;padding:6px;color:white;width:50px;box-shadow:0 0 5px white;border:1px solid white;background-color:#3473FA '># PAGINAS</span>
        <?php
            include_once ("../Model/dao.php");
            $dao = new Activos();
            $r1 = $dao->Activos1();
            $r = $dao->VerActivos(0);
            $num = $r1->num_rows/3;
            for($i = 1;$i<ceil($num)+1;$i=$i+1){
                $mirar = $i-1;
                echo "<button class='ml-3' style='border:none;padding:4px;color:white;width:50px;box-shadow:0 0 5px white;border:1px solid white;;background-color:#3473FA ' onClick='Activos(`".$mirar."`)'>".$i."</button>";
            }
        ?>
            </div>
            <div class="col-6">
             <h5 style="color:white;text-align:center;font-size:22px;font-family: Times New Roman, Times, serif;">CONTROL DE INVENTARIOS DEL SENA</h5>
            </div>
            <div class="col-3">
                <button style='display:block;margin:auto;border:none;padding:6px;color:white;width:150px;box-shadow:0 0 5px white;border:1px solid white;;background-color:#00AC2C ' onClick="Agregar()">AGREGAR</button>
            </div>
        </header>
        <div id="activos" style="overflow:hidden;">
        <?php
            while($ver=mysqli_fetch_row($r)){
                echo   '<form action="HojaVida" method="POST"><button type="submit" class="activoM">
                <div style="width:40%;float:left;padding:4px;">
                <h5 style="text-align:center">'.$ver[1].'</h5>
                <img style="display:block;margin:auto;width:80%;" src="Css/Img/'.$ver[4].'">
                </div>
                <div style="width:60%;float:left;padding:10px">
                <h5>ID : '.$ver[0].'</h5>
                <h5>Estado : '.$ver[2].'</h5>
                <h5>Fecha : '.$ver[3].'</h5>
                <input type="hidden" name="ID" value="'.$ver[0].'">
                </div>
            </button></form>';
            }
        ?>
        </div>
    </main>
    <?php include_once("footer.php") ?>
    </div>
    <div class="agregar animated faster" id="Agregar">
        <div class="header mb-3" >
            <h5>Agregar Nuevo Activo</h5>
            <button onClick="verDatos()" style="position:absolute;right: 11px;top:11px;border:1px solid white" class="btn btn-success"><img style="width:20px" src="<?php echo SERVERURL ?>Css/Img/plus.png" alt=""></button>
        </div>
            <table>
                <tbody id="agregarN">
                <tr class="N_Activo animated faster">
                    <td style="width:20%"><input style="text-align:center" placeholder="ID EQUIPO" class="Id" required></td>
                    <td style="width:20%">
                        <select  id="lista1" class="TipoActivo select" name="TipoEquipo" required>
                        <option hidden selected >SELECCIONA EQUIPO</option>
                        <?php
                            require_once("../Model/dao.php");
                            $c = new ReporteD();
                            $r = $c->EquipoaRerportar();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
                            } 
                            ?>  
                        </select>
                    </td>
                    <td style="width:20%">
                        <select  id="lista1" class="Accion select" name="TipoEquipo"  required>
                        <option hidden selected>ACCION</option>
                        <?php
                            $r = $c->TipoAccion();
                            while($clientes=mysqli_fetch_row($r))
                            {   

                                    echo "<option value='".$clientes[0]."'>".$clientes[1]."</option>";  

                            } 
                            ?>  
                        </select>
                    </td>
                    <td style="width:20%">
                        <select  id="lista1" class="EstadoActivo select" name="TipoEquipo"  required>
                        <option disabled >ESTADO ACTIVO</option>
                        <?php
                            $r = $c->EstadoActivo();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                if($clientes[0]==0){
                                    echo "<option selected value='".$clientes[0]."'>".$clientes[1]."</option>";  
                                }
                                else{
                                    echo "<option value='".$clientes[0]."'>".$clientes[1]."</option>";  
                                }
                            } 
                            ?>  
                        </select>
                    </td>
                    <?php $fcha = date("Y-m-d");?>
                    <td style="width:20%"><input class="Fecha" type="date" name="" value="<?php echo $fcha;?>" id=""></td>
                </tr>
                </tbody>
            </table>
            <table id="Agregar_E">

            </table>
        <input value="CONFIRMAR" type="Submit" class="btn btn-success" style="position:absolute;bottom:40px;width:30%;left:15%" onClick="confirmar()">
        <button class="btn btn-danger" style="position:absolute;bottom:40px;width:30%;right:15%;" onClick="Quitar()">CANCELAR</button>    
    </div>
    <div class="loader-page animated faster fadeInDown" id="loader-page"></div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
    function Activos($n){
        $.ajax({
        type:"POST",
        url:"Controller/RecargarActivos.php",
        data: {'n': $n},
        success:function(r){
            $('#activos').html(r);
        }});
    }

    function Agregar(){
        document.getElementById('Agregar').classList.remove("fadeOutUp");
        document.getElementById('Agregar').classList.add("fadeInDown");
        document.getElementById('Agregar').style.display="block";
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="0.2";
    }
    function Quitar() {
        document.getElementById('Agregar').classList.add("fadeOutUp");
        document.getElementById('Agregar').classList.remove("fadeInDown");
        setTimeout(function () {
            document.getElementById('Agregar').style.display="none";
        },400);
        
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="1";
        $("#agregarN").load("Controller/NuevoActivo.php");
        document.getElementById("Agregar_E").innerHTML = '';
    }
    var $n = $('#agregarN').html();
function verDatos(){
    var $divs1 = $(".Errores").toArray().length;
    if($divs1>0){
        $("#agregarN").load("Controller/NuevoActivo.php");
        document.getElementById("Agregar_E").innerHTML = '';
    }else{
        $.ajax({
        type:"POST",
        url:"Controller/NuevoActivo.php",
        data: {},
        success:function(r){
            $('#agregarN').prepend($n);
        }});
    }

}
    
function confirmar(){
    var $divs1 = $(".N_Activo").toArray().length;  
    var $divs = $(".N_Activo").toArray(); 
    var $TipoActivo = $(".TipoActivo").toArray();
    var $EstadoActivo = $(".EstadoActivo").toArray();
    var $Id = $(".Id").toArray();
    var $Fecha = $(".Fecha").toArray();
    for (var i = 0, j = 0; i < $divs1; i++, j++) {
    setTimeout(function() {
        $divs[this].classList.add("fadeOutLeft");
        $.ajax({
        type:"POST",
        url:"Controller/AgregarActivo.php",
        data: {'Id': $Id[this].value,'TipoEquipo': $TipoActivo[this].value,'EA': $EstadoActivo[this].value,'FI': $Fecha[this].value},
        success:function(r){
            $('#Agregar_E').append(r);
        }});
    }.bind(i), j * 200);
    }
    for (var i = 0, j = 0; i < $divs1; i++, j++) {
    setTimeout(function() {
        $divs[this].style.display="none";
    }.bind(i), j * 300);
    }
}
</script>          