<?php include_once('../config.php');
    include_once("../Model/user_session.php");
    $user = new UserSession();
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
                header("location: index");
            break;
            case 2:
                header("location: indexL");
            break;
            case 3:
                header("location:Reporte");
            break;
    }}else{
        header("location: Login");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/index.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.5.16/vue.min.js">
    </script>
</head>
<body>
    <?php
        require_once("navbarI.php");
    ?>
      <main class="mt-4 container mb-5">
          <div class="Header row">
            <h2 class="col-5">QUE HAY DE NUEVO?</h2>
            <div class="col-6 row">
                <h5 class="col-5">Reportes Nuevos</h5>
                <h5 style="text-align: left;" class="col-1">1</h5>
                <h5 class="col-5">Mensajes de reportes sin ver</h5>
                <h5 style="text-align: left;" class="col-1">20</h5>
            </div>
          </div>
          <hr style="border-bottom: 1px solid black;">
          <div class="main mt-5" style="po">
          <div style="display:block;margin:left;width:400px;">
          <h5>GRAFICA DE #REPORTES</h5>            </div>
      </main>
      <?php include_once("footer.php") ?>
</body>
</html>

<?php
include_once("../Model/dao.php");
        $dao = new Perfil();
        $r = $dao->DatosPerfil($_SESSION["user"]);
        while($ver1=mysqli_fetch_row($r)){
?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
if (document.referrer=="https://smwjvhak.lucusvirtual.es/Login") //si es verdadero quiere decir que vienes de algun lado
Swal.fire({
    title: 'Bienvenido <?php echo $ver1[1]; } ?>',
  showConfirmButton: false,
  timer: 1000
})
</script>