<?php include_once('../config.php');
    include_once("../Model/user_session.php");
    $user = new UserSession();
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
            break;
            case 2:
                header("location: indexL");
            break;
            case 3:
                header("location: indexI");
            break;
        }
    }else{
        header("location: Login");
    }?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/Registrar.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.5.16/vue.min.js">
    </script>
</head>
<body>
    <?php
        require_once("navbarA.php");
    ?>
    <main class="container mt-4" style="position:relative">
        <b style="position:absolute;top:5px;left:10%;width:80%;text-align:center;color:rgba(128, 128, 128, 0.603)">POR FAVOR RECUERDE LLENAR TODOS LOS CAMPOS</b>
        <b style="display:block;width:100%;text-align:center;font-size:32px">Registrar un nuveo usuario</b>
        <form action="Controller/CrearCuenta.php" method="POST">
            <div style="overflow:hidden">
                <div style="float:left;padding:20px;overflow:hidden;width:50%">
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">TIPO DE DOCUMENTO</div>
                    <div style="float:left;width:50%">
                    <select required class="inputs mt-4" name="TiDo" id="">
                        <option hidden selected >Tipo documento</option>
                        <?php
                            require_once("../Model/dao.php");
                            $c = new registrar();
                            $r = $c->TipoDo();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
                            } 
                            ?>  
                    </select>
                    </div>
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">NUMERO DE DOCUMENTO</div>
                    <div style="float:left;width:50%"><input required name="CC" class="inputs mt-4" type="text" placeholder="NUMERO DOCUMENTO"></div>
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">NOMBRES</div>
                    <div style="float:left;width:50%"><input required name="Nombre" class="inputs mt-4" type="text" placeholder="NOMBRES"></div>
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">APELLIDOS</div>
                    <div style="float:left;width:50%"><input required name="Apelli" class="inputs mt-4" type="text" placeholder="APELLIDOS"></div>
                </div>
                <div style="float:left;padding:20px;overflow:hidden;width:50%">
                <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">TIPO DE CUENTA</div>
                    <div style="float:left;width:50%">       
                        <select required  class="inputs mt-4" name="TipoCuenta" id="">
                            <option hidden selected >Tipo Cuenta</option>
                            <?php
                            $r = $c->TipoCu();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
                            } 
                            ?> 
                        </select>
                    </div>
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">CORREO</div>
                    <div style="float:left;width:50%"><input required name="Correo" class="inputs mt-4" type="text" placeholder="CORREO"></div>
                    <div style="float:left;width:50%;text-align:center;padding:6px" class="mt-4">CONTRASEÑA</div>
                    <div style="float:left;width:50%"><input required name="Pass" class="inputs mt-4" type="password" placeholder="CONTRASEÑA"></div>
                </div>
            </div>
            <div class="mt-5" style="width:100%"><input style="display:block;margin:auto;width:250px" class="mt-4 btn btn-success" value="CONFIMAR" type="submit"></div>
        </form>
    </main>
    <?php include_once("footer.php") ?>

</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php
if(isset($_GET["O"])){
 if($_GET["O"]==1){
     echo "<script>Swal.fire({
  position: 'bottom-end',
  icon: 'success',
  title: 'Todo salio bien registros creados con exito',
  toast: true,
  showConfirmButton: false,
  timer: 4000
})</script>";
 }if($_GET["O"]==2){
     echo "<script>Swal.fire({
  position: 'bottom-end',
  icon: 'error',
  title: 'Ocurrio un problema al registrar los datos',
  toast: true,
  showConfirmButton: false,
  timer: 4000
})</script>";
 }if($_GET["O"]==3){
     echo "<script>Swal.fire({
  position: 'bottom-end',
  icon: 'error',
  title: 'Por favor inserta todos los datos',
  toast: true,
  showConfirmButton: false,
  timer: 4000
})</script>";
 }
}
?>