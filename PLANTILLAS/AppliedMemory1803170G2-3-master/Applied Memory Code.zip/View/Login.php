<?php
     include_once("../Model/user_session.php");
     include_once("../Model/User.php");
     $user = new User();
     $userSession = new UserSession();
     if(isset($_SESSION["user"])){
        header("location: index"); 
     }else{
     }
?>
<!DOCTYPE html>
<?php include_once('../config.php')?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Css/Img/Logo.PNG" type="image/png">
    <title>Inicio Sesion</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="Css/Login.css">
</head>
<body >
    <div class="contenedor">
        <div class="log container animated fadeInLeft">
            <h2>BIENVENIDO </h2>
            <br> 
            <h3>CONTROL DE INVENTARIO SENA</h3>
            <img src="Css/Img/Sena.png" alt="">
        </div>
        <div class="form">
            <div class="container animated pulse delay-1s">
            <h5>INICIO SESION</h5>
            <img src="Css/Img/Logo.PNG" alt="">
                <form action="Controller/Verificar.php" Method="POST">
                    <input name="username" style="margin-top: 20px;" class="inp" type="text" placeholder="USUARIO">
                    <br>
                    <input name="password" class="inp" type="password" placeholder="CONTRASEÑA">
                    <br>
                    <input style="margin: auto;display: block;width: 200px;margin-top: 1%;" class="btn btn-danger" type="submit" value="INGRESAR">
                </form>
                <a onClick="olvidecontra()" class="olvide">olvidaste tu contraseña</a>            
            </div>
        </div>
    </div>
</body>
<?php
 
 function get_random_string($length = 8){
     $cons = array('b','c','d','f','g','h','j','k','l',  
                   'm','n','p','r','s','t','v','w','x','y','z');
     $voca = array('a','e','i','o','u');
     $num = array("1","2","3","4","5","6","7","8","9","0");
     
     srand((double)microtime()*1000000);
     
     $max = $length/2;
     $password = '';
     for($i=1;$i<=$max;$i++){
         $password .= $cons[rand(0,count($cons)-1)];
         $password .= $voca[rand(0,count($voca)-1)];
         $password .= $num[rand(0,count($num)-1)];
     }
  
     if(($length % 2) == 1) $password .= $cons[rand(0,count($cons)-1)];
  
     return $password;
 }
?>
</html>
<script
	src="https://code.jquery.com/jquery-3.3.1.min.js"
	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php if(isset($_GET["E"])){
    echo "<script>Swal.fire({
  position: 'bottom-end',
  icon: 'error',
  title: 'usuario y/o contraseña incorrecta',
  toast: true,
  showConfirmButton: false,
  timer: 4000
})</script>";}
?>
<script>
function olvidecontra() {
  Swal.fire({
    title: "Escribe tu correo electronico",
       html: "<input id='ced' type='text' style='text-align:center' placeholder='Correo'><br>",
  showCancelButton: true,
  confirmButtonText: 'Confimar!',
  cancelButtonText: 'Cancelar!',
  reverseButtons: true
}).then((result) => {
  if (result.value) {
    continar()
  } else if (
    /* Read more about handling dismissals below */
    result.dismiss === Swal.DismissReason.cancel
  ) {
  }
})
}
function continar(){
    var $ced = $("#ced").val();
    if($("#ced").val()!=""){
        alert($ced);
      $.ajax({
        type:"POST",
        url:"Controller/RecuperarContraseña.php",
        data: {'email': $ced},
        success:function(r){
          if(r==1){
            $.ajax({
                type:"POST",
                url:"Controller/GuardarContraseña.php",
                data: {'pass': '<?php echo $contraN = get_random_string(8); ?>','user' : $ced},
                success:function(s){
                  
                }        
            });
            enviar($ced,'<?php echo $contraN ?>');
            Swal.fire(
                            'CORRECTO',
                            'Se envio un correo a la cuenta '+$ced+'',
                            'success'
                        )
          }else{
            Swal.fire(
                            'PROBLEMAS',
                            'El correo '+$ced+' no se encuentra verfique el correo',
                            'error'
                        )
          }
        }
    });

    }
}
</script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emailjs-com@2.3.2/dist/email.min.js"></script>
    <script>
        function enviar($correo,$contra){
            params = {
                para : $correo,
                from_name : "Applied Memory",
                from_email : "appliedmemoryweb@gmail.com",
                subject : "RECUPERAR CONTRASEÑA",
                message : "Applied Memory: su nueva contraseña es :"+$contra

            }
            emailjs.send('gmail','enviarcorreo', params, 'user_3pujIP6xNYneNSUMguzkC')
                .then((response) => {
                console.log('SUCCESS!', response.status, response.text);
                }, (err) => {
                console.log('FAILED...', err);
                });
        }
</script>