<div class="mt-5 pt-4 pb-1 footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-xs-12 about-company">
          <h2>Applied Memory</h2>
          <p class="pr-5 text-white-50">Applie Memory es un aplicativo web del Sena con el fin de ayudar al control de inventarios TI</p>
          <p><a href="#"><i class="fa fa-facebook-square mr-1"></i></a><a href="#"><i class="fa fa-linkedin-square"></i></a></p>
        </div>
        <div class="col-lg-3 col-xs-12 links">
          <h4 class="mt-lg-0 mt-sm-3 ml-3">SENA</h4>
        <a target="_blank" href="http://www.sena.edu.co/es-co/Paginas/default.aspx"><img class="SenaLogo" src="Css/Img/Sena.png" alt=""></a>
        </div>
        <div class="col-lg-4 col-xs-12 location">
          <h4 class="mt-lg-0 mt-sm-4">Ubicación</h4>
          <p>Cl. 69 #20-36, Bogotá</p>
          <p class="mb-1"><i class="fa fa-phone mr-3"></i> (5) 4541411</p>
          <p><i class="fa fa-envelope-o mr-3"></i>servicioalciudadano@sena.edu.co</p>
        </div>
      </div>
      <div class="row mt-4">
        <div class="col copyright">
          <p class=""><small class="text-white-50">© 2019. Applied Memory.</small></p>
        </div>
      </div>
    </div>
    </div>