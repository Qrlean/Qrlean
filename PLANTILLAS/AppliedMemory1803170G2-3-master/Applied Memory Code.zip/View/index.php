<?php 
    include("../Model/user_session.php");
    $user = new UserSession();
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
                
            break;
            case 2:
                header("location: indexL");
            break;
            case 3:
                header("location: indexI");
            break;
        }
    }else{
        header("location: Login");
    }?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/index.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.5.16/vue.min.js">
    </script>
</head>
<body>
    <?php
        require_once("navbarA.php");
    ?>
      <main style="overflow:hidden" class="mt-4 container mb-5">
          <div style="width:60%;float:left" class="Header row">
            <div class="col-12"><h2 style="text-algin:center">RESUMEN DEL APLICATIVO</h2></div>
            <div class="col-12">
                <div class="mb-3 mt-4" style="display:block;margin:auto;padding:12px;width:90%;box-shadow:0 0 10px black">
                    <?php
                        require_once("../Model/dao.php");
                        $c = new ReporteD();
                        $l = $c->todoslosreportes();
                        $r = $c-> SeleccionarTodosReportes(); 
                    ?>
                    <h5 style="text-align:center">TOTAL REPORTES : <?php echo $l->num_rows;?></h5>
                    <hr style="border:1px solid gray">
                    <div >
                    <div style="display: inline-block;width:33%;text-align:center">Solucionados : <?php echo $r[0] ?></div><div style="display: inline-block;width:33%;text-align:center">Reportados : <?php echo $r[1] ?></div><span style="display: inline-block;width:33%;text-align:center">En solucion : <?php echo $r[2] ?></span>
                    </div>
                </div>
                <?php
                        require_once("../Model/dao.php");
                        $c1 = new Activos();
                        $l1 = $c1->Activos1();
                        $r1 = $c1->verActivosIndex();
                    ?>
                <div class="mb-3" style="display:block;margin:auto;padding:12px;width:90%;box-shadow:0 0 10px black">
                    <h5 style="text-align:center">TOTAL ACTIVOS : <?php echo $l1->num_rows?></h5>
                    <hr style="border:1px solid gray">
                    <div style="display: inline-block;width:50%;text-align:center">En Buen Estado : <?php echo $r1[0] ?></div><div style="display: inline-block;width:50%;text-align:center">Con fallas : <?php echo $r1[1] ?></div>
                </div>
            </div>
          </div>
          <div style="width:40%;float:left" class="main mt-5">
          <div style="display:block;margin:auto;width:400px;">
          <h5>GRAFICA DE #REPORTES</h5>
                    <canvas id="myChart" width="400" height="400" ></canvas>
            </div>
      </main>
      <?php include_once("footer.php") ?>
</body>
</html>

<?php
include_once("../Model/dao.php");
        $dao = new Perfil();
        $r = $dao->DatosPerfil($_SESSION["user"]);
        while($ver1=mysqli_fetch_row($r)){
?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
if (document.referrer=="https://smwjvhak.lucusvirtual.es/Login") //si es verdadero quiere decir que vienes de algun lado
Swal.fire({
    title: 'Bienvenido <?php echo $ver1[1]; } ?>',
  showConfirmButton: false,
  timer: 1300
})
</script>
<?php 
    require_once("../Model/dao.php");
    $c = new ReporteD();
    $r = $c-> SeleccionarTodosReportes(); 
?>
<script>
grafica();
function grafica(){
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['SOLUCIONADOS', 'EN SOLUCION', 'REPORTADOS'],
        datasets: [{
            label: 'GRAFICA DE #REPORTES',
            data: [<?php echo $r[0]?>, <?php echo $r[2]?>, <?php echo $r[1]?>],
            backgroundColor: [
                'rgba(75, 192, 192, 0.6)',
                'rgba(255, 206, 86, 0.6)',
                'rgba(255, 99, 132, 0.6)'
            ],
            borderColor: [
                'rgba(75, 192, 192, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 99, 132, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }, options: {
       responsive: true,
       legend: {
         position: 'bottom',
       },
       title: {
         display: false,
         text: 'Chart.js Doughnut Chart'
       },
       animation: {
         animateScale: true,
         animateRotate: true
       },
       tooltips: {
         callbacks: {
           label: function(tooltipItem, data) {
           	var dataset = data.datasets[tooltipItem.datasetIndex];
             var total = dataset.data.reduce(function(previousValue, currentValue, currentIndex, array) {
               return previousValue + currentValue;
             });
             var currentValue = dataset.data[tooltipItem.index];
             var precentage = Math.floor(((currentValue/total) * 100)+0.5);         
             return precentage + "%";
           }
         }
       }
    }
});
}
</script>