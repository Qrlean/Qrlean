<!DOCTYPE html>
<?php include_once('../config.php')?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo SERVERURL;?>/Css/index.css">
    <link rel="stylesheet" href="Css/Perfil.css">
</head>
<body>
    <?php     
        include_once("../Model/user_session.php");
        $userSession = new UserSession();
        if(isset($_SESSION["user"])){
            switch($_SESSION["rol"]){
                case 1:
                    require_once("navbarA.php");
                break;
                case 2:
                    require_once("navbarL.php");
                break;
                case 3:
                    require_once("navbarI.php");
                break;
            }
        }else{
            header("location: Login");
        }
 ?>
<main class="mt-4 container">
    <div style='overflow:hidden'>
        <div style='width:33%;float:left;padding:10px'>
            <h5 style='text-align:center'>PERFIL</h5>
            <div style="display:block;margin:auto;width:250px;height:250px;box-shadow:0 0 5px black"></div>
            <input type='file' style='width:250px;display:block;margin:auto' class="mt-3 btn">
        </div>
        <div style='width:33%;float:left;padding:35px'>
            <?php
            include_once("../Model/dao.php");
            $dao = new Perfil();
            $r = $dao->DatosPerfil($_SESSION["user"]);
            while($ver1=mysqli_fetch_row($r)){
                echo "<h5>".$ver1[5]."</h5><p>".$ver1[0]."<p>";
                echo "<h5>Nombre</h5><p>".$ver1[1]."<p>";
                echo "<h5>Apellido</h5><p>".$ver1[2]."<p>";
                
            }
            ?>
        </div>
        <div style='width:33%;float:left;padding:35px'>
            <button style='display:block;margin:auto' class="btn btn-info">cambiar contraseña</button>
        </div>
    </div>
</main>
<?php include_once("footer.php") ?>
</body>
</html>