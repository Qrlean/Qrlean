<?php 
include_once("../Model/user_session.php");
$userSession = new UserSession();
?>
<!DOCTYPE html>
<?php include_once('../config.php');?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Css/realizarreporte.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
</head>
<body>
<?php
if(isset($_SESSION["user"])){
    if($_SESSION["rol"]!=3){
        header("location: index"); 
    }
    else{
        include_once("navbarI.php");
    }
}else{
    header("location: Login"); 
}
?>
<div id="body" class="container row" style="margin:auto">
<?php
    if(isset($_GET["M"])){
       if($_GET["M"]==1){

        }
        if($_GET["M"]==2){        
            
        }
    }
?>
<main class="col-6 main mt-4 mr-4">
    <div class="header">
        <h5>REPORTE POR FALLA DE EQUIPOS</h5>
    </div>
    <div class="form mb-4">
        <form class="row container" method="POST" action="<?php echo SERVERURL;?>Controller/RealizarReporte.php">
            <div class="col-6 mb-5">
                <h6>Que componente deseas reportar</h6>
                <select  id="lista1" class="select" name="TipoEquipo"  required>
                <option value="0">SELECCIONA EQUIPO</option>
                <?php
                    require_once("../Model/dao.php");
                    $c = new ReporteD();
                    $r = $c->EquipoaRerportar();
                    while($clientes=mysqli_fetch_row($r))
                    {   
                        echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
                    } 
                    ?>  
                </select>
            </div>
            <div class="col-6 mb-5">
                <h6>Ambiente</h6>
                <input type="text" placeholder="Ambiente" name="Ambiente" required>
            </div>
            <div class="col-6">
                <h6>Numero de equipo en el ambiente</h6>
                <input type="text" placeholder="Num_Equipo" name="NumEquipo" required>
            </div>
            <div class="col-6">
                <h6>Mensaje Del fallo</h6>
                <input type="text" placeholder="Mensaje" name="Mensaje" required>
            </div>
            <div class="col-12 mt-5">
            <button class="btn btn-success">CONFIRMAR</button>
            </div>
            <input type="hidden" value="<?php echo $_SESSION["user"]?>" name="CC">
        </form>
    </div>
</main>
<main style="max-height:500px;" class="col-5 ml-5 mt-4">
    <div class="col-12 header mb-3">
        <h5>REGISTRO REPORTES</h5>
    </div>
    <div class="main-reporte">
    <?php 
        $r2 = $c->NumReportes($_SESSION["user"]);
        while($clientes=mysqli_fetch_row($r2))
        {   
            echo "<div onClick='VerReporte(".$clientes[2].")' class='row col-12 reporte mb-1 mt-1'>
            <span class='col-4'>".$clientes[0]."</span>
            <span class='col-5'>".$clientes[1]."</span>
            <div class='col-3'>
            <img  src='Css/Img/interface.png' alt=''>
            </div>
            </div>";  
        } 
    ?>
    </div>
</main>
</div>
<div id="mensajeria" class="mensajeria animated faster">
        <div class="padding">
            <div class="Chat ml-4">
                    <div class="header">
                        <header > <br> /  / </header>
                        <button onClick="Cancelar2()" class="btn btn-danger">VOLVER</button>
                    </div>
                    <div id="MostrarChat" class="main mt-1 mb-1">
                    
                    </div>
                    <div class="footers">
                    <input id="mensaje" class="text" type="text"><img id="enviar" onClick="name()" src="Css/Img/communications.png" alt="">
                    </div>
            </div>
        </div>
    </div>
<main id="Resumen" class="Resumen animated faster">
</main>
<?php include_once("footer.php") ?>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script type="text/javascript">
    function VerReporte($id){
        $.ajax({
        type:"POST",
        url:"Controller/VerReporte.php",
        data: {'IdMensaje': $id,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#Resumen').html(r);
            const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success ',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
            })
                Swal.fire({
                html: r,
                showCancelButton: true,
                confirmButtonText: 'VER CHAT',
                width: '50%',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    cambio($id)
                }
                });
            
        }});
    }
    function Cancelar(){
        document.getElementById('Resumen').classList.remove("fadeInDown");
        document.getElementById('Resumen').classList.add("fadeOutUp");
        setTimeout("Quitar()",400);
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="1";
        var mostrar = document.getElementById("Resumen");
    }
    function Quitar(){
        document.getElementById('Resumen').style.display="none"
    }
    function Cancelar2(){
        clearInterval(va);
        document.getElementById('mensajeria').classList.remove("fadeInDown");
        document.getElementById('mensajeria').classList.add("fadeOutUp");
        setTimeout("Quitar2()",400);
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="1";
        var mostrar = document.getElementById("Resumen");
    }
    function Quitar2(){
        document.getElementById('mensajeria').style.display="none"
    }
</script>
<script type="text/javascript">
var va;
function cambio($cc){
    document.getElementById('Resumen').classList.remove("fadeInDown");
    document.getElementById('Resumen').classList.add("fadeOutUp");
    setTimeout("Quitar()",400);
    document.getElementById('mensajeria').style.display="block";
    document.getElementById('mensajeria').classList.remove("fadeOutUp");
    document.getElementById('mensajeria').classList.add("fadeInDown");
    clearInterval(va);
    recargarLista($cc)
}
function mostrarlista(){
    $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/ajax.php",
        data: {'chatAver': $cc,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#MostrarChat').html(r);}
    
    });
}
function recargarLista($cc){
    clearInterval(va);
    $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/ajax.php",
        data: {'chatAver': $cc,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#MostrarChat').html(r);
        }})
    va = setInterval(function(){
        $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/ajax.php",
        data: {'chatAver': $cc,'CC': <?php echo $_SESSION["user"]; ?>},
        success:function(r){
            $('#MostrarChat').html(r);
        }});
    }, 2000)}
</script>
<script>
$("#enviar").click(function(){
    name();
});
function name() {
    $.ajax({
        type:"POST",
        url:"<?php echo SERVERURL;?>Controller/EnviarMensaje.php",
        data: {'mensaje': $('#mensaje').val(),'id': $('#chat').val(),'CC': <?php echo $_SESSION["user"]; ?>}
    });
    $('#mensaje').val('');
}
$('#mensaje').keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if(keycode == '13'){
        name();
    }
});
</script>
<script>
<?php  ?>
<?php if(isset($_GET["x"])){
    $id = $_GET["x"];
    echo "VerReporte('".$id."')";
} ?>
</script>