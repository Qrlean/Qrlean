<?php include_once('../config.php');
    include_once("../Model/user_session.php");
    $userSession = new UserSession();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Activos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Css/HojaVIda.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
</head>
<body >
    <div id="body">
<?php 
    if(isset($_SESSION["user"])){
        switch($_SESSION["rol"]){
            case 1:
                require_once("navbarA.php");
            break;
            case 2:
                require_once("navbarL.php");
            break;
            case 3:
                header("location: index");
            break;
        }
    }else{
        header("location: Login");
    }
    ?>  
    <?php if(isset($_POST["ID"])): ?>

        <main style="" class="container mt-4">
        <div style="padding:20px;overflow:hidden">
        <div style="width:50%;float:left;box-shadow:0 0 10px black;padding:10px">
                <h5 style="text-align:center">
                    MOFICACIONES ACTIVO # <?php echo $_POST["ID"] ?>
                </h5>
            <?php
            include_once ("../Model/dao.php");
            $dao = new Activos(); 
            $r = $dao->VerActivoPorID($_POST["ID"]); 
            while($ver=mysqli_fetch_row($r)){
                echo "<img style='display:block;margin:auto;width:230px' src='Css/Img/".$ver[4]."'>";
            ?>
        </div>
        <div style="text-align:center;font-size:26px;overflow:hidden;width:50%;float:left">
                <div style="height:70px;width:50%;float:left">Tipo Activo :</div>
                <div style="height:70px;width:50%;float:left"><?php echo $ver[1] ?></div>
                <div style="height:70px;width:50%;float:left">Estado Activo :</div>
                <div style="height:70px;width:50%;float:left"><?php echo $ver[2] ?></div>
                <div style="height:70px;width:50%;float:left">Fecha Ingreso :</div>
                <div style="height:70px;width:50%;float:left"><?php echo $ver[3] ?></div>
                <div style="height:70px;width:50%;float:left"><a href="Activos" style="width:150px;display:block;margin:auto" class="btn btn-danger">Volver</a></div>
                <div style="height:70px;width:50%;float:left"><a style="width:150px;display:block;margin:auto;color:white" class="btn btn-success" onClick="Modificar('<?php echo $_POST["ID"] ?>')">MODIFCAR</a></div>
            <?php } ?>
        </div>
        </div>
        <div class="mt-3">
        <table >
            <tr class="Titulos">
                <td>Id</td>
                <td>Modificacion</td>
                <td>Ambiente</td>
                <td>#Doc. Aprendiz</td>
                <td>#Doc. Tecnico</td>
                <td>Fecha</td>
            </tr>
            <tr></tr>
        <?php 
            include_once ("../Model/dao.php");
            $dao = new Activos();
            $r = $dao->HojaVida($_POST["ID"]);
            while($ver=mysqli_fetch_row($r)){
                echo "<tr class='cont'><td style='width:10%'>".$ver[0]."</td>";
                echo "<td style='width:20%'>".$ver[1]."</td>";
                if($ver[3]==''){
                    echo "<td style='color:red;width:10%'>";
                    echo "no aplica </td>";
                }else {
                    echo "<td style='width:10%'>";
                    echo $ver[3]."</td>";

                }
                if($ver[5]==''){
                    echo "<td style='color:red;width:20%'>";
                    echo "no aplica </td>";
                }else {
                    echo "<td style='width:20%'>";
                    echo $ver[5]."</td>";
                }
                echo "<td style='width:20%'>".$ver[4]."</td>";
                echo "<td style='width:20%'>".$ver[2]."</td></tr>";
            }
        ?>
        </table>
        </div>
        </main>

    <?php else: ?>

    <main class="container mt-4">
        <h5 style="text-align:center">NO SELECCIONASTE NINGUN ACTIVO</h5>
    </main>

    <?php endif ?>
    <?php include_once("footer.php") ?>
    </div>
    <div class="ModificarA animated faster" id="Modificar">
    <div class="header mb-3" >
            <h5>MODIFICAR ACTIVO # <span id="IdActivo"></span></h5>
        </div>
        <table>
            <tr>
            <input type="hidden" id="NactioV" value="">
                <td style="width:25%">
                    <h6 style="text-align:center">Accion a realizar </h6>
                </td>
                <td style="width:25%">
                        <select style="display:block;margin:auto;"  id="Accion" class="select" id="TipoModificacion" name="TipoEquipo"  required>
                        <option value="0" hidden selected>MODIFICACION</option>
                        <?php
                            require_once("../Model/dao.php");
                            $c = new ReporteD();
                            $r = $c->TipoAccion();
                            while($clientes=mysqli_fetch_row($r))
                            {   

                                    echo "<option value='".$clientes[0]."'>".$clientes[1]."</option>";  

                            } 
                            ?>  
                        </select>
                </td>
            </tr>
            <tr>
            <td >
                    <h6 style="text-align:center">Estado Activo</h6>
                </td>
                    <td style="">
                        <select style="display:block;margin:auto;" id="EstadoActivo" class="select" name="TipoEquipo"  required>
                        <option disabled >ESTADO ACTIVO</option>
                        <?php
                            require_once("../Model/dao.php");
                            $c = new ReporteD();
                            $r = $c->EstadoActivo();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                if($clientes[0]==0){
                                    echo "<option selected value='".$clientes[0]."'>".$clientes[1]."</option>";  
                                }
                                else{
                                    echo "<option value='".$clientes[0]."'>".$clientes[1]."</option>";  
                                }
                            } 
                            ?>  
                        </select>
                    </td>
                    </tr>
                    <tr class="Ambiente animated faster" id="Ambiente">
            <td >
                    <h6 style="text-align:center">AMBIENTE</h6>
                </td>
                    <td style="">
                        <select style="display:block;margin:auto;"  id="IdAmbiente" class="select" name="TipoEquipo"  required>
                        <option hidden selected>AMBIENTE</option>
                        <?php
                            require_once("../Model/dao.php");
                            $c = new Activos();
                            $r = $c-> Ambientes();
                            while($clientes=mysqli_fetch_row($r))
                            {   
                                echo "<option value='".$clientes[0]."'>".$clientes[0]."</option>";  
                            } 
                            ?>  
                        </select>
                    </td>
                    </tr>
                    <tr class="Ambiente animated faster" id="CC_PERSONA">
            <td >
                    <h6 style="text-align:center">CEDULA</h6>
                </td>
                    <td style="">
                        <input style="display:block;margin:auto;" id="CCAprendiz"  class="select" name="TipoEquipo" type="number" min="0" style="" required>
                    </td>
                    </tr>
        </table>
        <input value="CONFIRMAR" type="Submit" class="btn btn-success" style="position:absolute;bottom:40px;width:30%;left:15%" onClick="confirmarM()">
        <button class="btn btn-danger" style="position:absolute;bottom:40px;width:30%;right:15%;" onClick="QuitarM()">CANCELAR</button>  
    </div>
</body >
<script>
    function Modificar($Id){
        document.getElementById('Modificar').classList.remove("fadeOutUp");
        document.getElementById('Modificar').classList.add("fadeInDown");
        document.getElementById('Modificar').style.display="block";NactioV
        document.getElementById('IdActivo').innerHTML = $Id;
        document.getElementById('NactioV').value = $Id;
        document.getElementById("body").style.pointerEvents="none"
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="0.2";
    }
    function QuitarM(){
        document.getElementById('Modificar').classList.remove("fadeInDown");
        document.getElementById('Modificar').classList.add("fadeOutUp");
        setTimeout(function () {
            document.getElementById('Modificar').style.display="none";
        },400);
        
        var Opacidad = document.getElementById("body");
        Opacidad.style.opacity="1";
        document.getElementById("body").style.pointerEvents="auto"
    }
    function confirmarM(){
    $.ajax({
        type:"POST",
        url:"Controller/AgregarModificacion.php",
        data: {'Accion': $("#Accion").val(),'ID': $("#NactioV").val(),'CC': <?php echo $_SESSION["user"] ?>,'EstadoActivo': $("#EstadoActivo").val(),'Ambiente': $("#IdAmbiente").val(),'CC_Aprendiz': $("#CCAprendiz").val()},
        success:function(r){
            $('#Modificar').append(r);
    }});
        $("#Accion").val() = "0";
    }
function ModificarP(){
    document.getElementById('Modificar').style.height="40%";
    }
    function ModificarM(){
        document.getElementById('Modificar').style.height="48%";
    }
    function ModificarG(){
        document.getElementById('Modificar').style.height="55%";
    }
</script>
<script>
    $(document).ready(function(){
        ModificarP()
    $('#Accion').change(function(){
        Accion();
    });
});
function Accion(){
    $val = document.getElementById('Accion').value;
    if($val==2){
        ModificarM()
        document.getElementById('Ambiente').classList.add("fadeInLeft");
        document.getElementById('Ambiente').classList.remove("fadeOutLeft");
        document.getElementById('Ambiente').classList.remove("Ambiente");
        document.getElementById('Ambiente').classList.add("Block");
        document.getElementById('CC_PERSONA').classList.remove("Block");
        document.getElementById('CC_PERSONA').classList.add("Ambiente");
    }
    if($val==3){
        ModificarG()
        document.getElementById('CC_PERSONA').classList.add("fadeInLeft");
        document.getElementById('CC_PERSONA').classList.remove("fadeOutLeft");
        document.getElementById('Ambiente').classList.add("fadeInLeft");
        document.getElementById('Ambiente').classList.remove("fadeOutLeft");
        document.getElementById('CC_PERSONA').classList.remove("Ambiente");
        document.getElementById('CC_PERSONA').classList.add("Block");
        document.getElementById('Ambiente').classList.remove("Ambiente");
        document.getElementById('Ambiente').classList.add("Block");
    }
    if($val==1){
        ModificarP()
        document.getElementById('Ambiente').classList.remove("Block");
        document.getElementById('Ambiente').classList.add("Ambiente");
        document.getElementById('CC_PERSONA').classList.remove("Block");
        document.getElementById('CC_PERSONA').classList.add("Ambiente");
    }
}
</script>