<?php
class Datos{
    private $Usuario;
    private $Contraseña;
    private $CC;
    public function setUsuario($usuario){
        $this->Usuario = $usuario;
    }
    public function getUsuario(){
        return $this->Usuario;
    }
    public function setContraseña($Contraseña){
        $this->Contraseña = $Contraseña;
    }
    public function getContraseña(){
        return $this->Contraseña;
    }
    public function setCC($CC){
        $this->CC = $CC;
    }
    public function getCC(){
        return $this->CC;
    }
}
class Reporte{
    private $Ambiente;
    private $CC;
    private $TipoEquipo;
    private $Num_Equipo;
    Private $Mensaje;
    public function setCC($CC){
        $this->CC = $CC;
    }
    public function getCC(){
        return $this->CC;
    }
    public function setTipoEquipo($TipoEquipo){
        $this->TipoEquipo = $TipoEquipo;
    }
    public function getTipoEquipo(){
        return $this->TipoEquipo;
    }
    public function setNum_Equipo($Num_Equipo){
        $this->Num_Equipo = $Num_Equipo;
    }
    public function getNum_Equipo(){
        return $this->Num_Equipo;
    }
    public function setMensaje($Mensaje){
        $this->Mensaje = $Mensaje;
    }
    public function getMensaje(){
        return $this->Mensaje;
    }
    public function setAmbiente($Ambiente){
        $this->Ambiente = $Ambiente;
    }
    public function getAmbiente(){
        return $this->Ambiente;
    }
}
class ActivosM{
    private $Ambiente;
    private $CC;
    private $id;
    private $TipoEquipo;
    private $EstadoEquipo;
    private $Fecha_Ingreso;
    private $Modificacion;
    private $CCAprendiz;
    public function setCC($CC){
        $this->CC = $CC;
    }
    public function getCC(){
        return $this->CC;
    }
    public function setCCAprendiz($CCAprendiz){
        $this->CCAprendiz = $CCAprendiz;
    }
    public function getCCAprendiz(){
        return $this->CCAprendiz;
    }
    public function setAmbiente($Ambiente){
        $this->Ambiente = $Ambiente;
    }
    public function getAmbiente(){
        return $this->Ambiente;
    }
    public function setId($CC){
        $this->Id = $CC;
    }
    public function getId(){
        return $this->Id;
    }
    public function setTipoEquipo($TipoEquipo){
        $this->TipoEquipo = $TipoEquipo;
    }
    public function getTipoEquipo(){
        return $this->TipoEquipo;
    }
    public function setEstadoEquipo($EstadoEquipo){
        $this->EstadoEquipo = $EstadoEquipo;
    }
    public function getEstadoEquipo(){
        return $this->EstadoEquipo;
    }
    public function setFecha_Ingreso($Fecha_Ingreso){
        $this->Fecha_Ingreso = $Fecha_Ingreso;
    }
    public function getFecha_Ingreso(){
        return $this->Fecha_Ingreso;
    }
    public function setModificacion($Modificacion){
        $this->Modificacion = $Modificacion;
    }
    public function getModificacion(){
        return $this->Modificacion;
    }
}
?>