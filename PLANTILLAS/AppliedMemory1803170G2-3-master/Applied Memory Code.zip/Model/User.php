<?php
include_once("../Conexion/conexion.php");
class User{
    private $cc;
    public $Rol;

    public function userExists($user,$pass){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $md5pass = md5($pass);
        $r =  mysqli_query($conexion,"SELECT CC,TipoCuenta from usuarios where usuario='$user' AND contrasena='$md5pass'");
        if($r->num_rows>0){
            while($ver1=mysqli_fetch_row($r)){
                $this->cc=$ver1[0];
                $this->Rol=$ver1[1];
            }
            return true;
        }else{
            return false;
        }
    }
    public function getRol(){
        return $this->Rol;
    }
    public function getCc(){
        return $this->cc;
    }
}
?>