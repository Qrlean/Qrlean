<?php
require_once('../Conexion/conexion.php');
class registrar{
    public function TipoDo(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from tipodo");
        return $r;
    }
    public function TipoCu(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from tipocuenta");
        return $r;
    }
    public function InsertarDatos($CC,$Nombre,$Apellido,$TipoDoc){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"INSERT INTO datos (CC,Nombres,Apellidos,TipoDoc) values($CC,'$Nombre','$Apellido',$TipoDoc)");
        return $r;
    }
    public function InsertarCuenta($CC,$usuario,$contrasena,$TipoCue){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $pass = md5($contrasena);
        $r =  mysqli_query($conexion,"INSERT INTO usuarios (usuario,contrasena,CC,TipoCuenta) values('$usuario','$pass',$CC,$TipoCue)");
        return $r;
    }
}
class Perfil{
    public function connect(){

    } 
    public function DatosPerfil($CC){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from datos where CC = $CC");
        return $r;
    }
    public function EstadoLinea($e,$CC){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"UPDATE usuarios SET EstadoO = $e where CC = $CC");
    }
    public function TipoDocumento(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from tipocuenta");
        return $r;
    }
}
class chat{
    public function Chats(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from chats");
        return $r;
    }
    public function DatosI($CC){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT datos.Nombres,datos.Apellidos,usuarios.EstadoO from datos join usuarios on datos.CC = usuarios.CC where datos.CC=$CC");
        return $r;
    }
}
class ReporteD{
    public function todoslosreportes(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * FROM reporte");
        return $r;
    }
    public function SeleccionarTodosReportes(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $pila = array();
        $r =  mysqli_query($conexion,"SELECT * from reporte where EstadoReporte = 1");
        $n = $r->num_rows;
        array_push($pila,$n);
        $r1 =  mysqli_query($conexion,"SELECT * from reporte where EstadoReporte = 2");
        $n1 = $r1->num_rows;
        array_push($pila,$n1);
        $r2 =  mysqli_query($conexion,"SELECT * from reporte where EstadoReporte = 3");
        $n2 = $r2->num_rows;
        array_push($pila,$n2);
        return $pila;
    }
    public function EstadoReporte($id,$e){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"UPDATE reporte SET EstadoReporte = $e where IdReporte = $id");
        return $r;
    }
    public function TipoAccion(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * FROM tipo_modificacion");
        return $r;
    }
    public function EquipoaRerportar(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from tipoactivo");
        return $r;
    }
    public function EstadoActivo(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from estadoactivo");
        return $r;
    }
    public function CrearChat($CC){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $Buscar = mysqli_query($conexion,"SELECT MAX(IdReporte) from reporte");
        $id;
        if($Buscar){
            while($ver=mysqli_fetch_row($Buscar)){
                $id = $ver[0];
            }
        }

        $r =  mysqli_query($conexion,"INSERT INTO chats (CC_Instructor,Id_Reporte) VALUES ($CC,$id)");
        
    }
    public function RegistrarReporte(Reporte $M){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $fecha = date('Y/m/d'); 
        $r =  mysqli_query($conexion,"INSERT INTO reporte (TipoEquipo,Num_Equipo,Ambiente,falla,CC,Fecha,EstadoReporte) VALUES (".$M->getTipoEquipo().",".$M->getNum_Equipo().",".$M->getAmbiente().",'".$M->getMensaje()."',".$M->getCC().",'$fecha','2')");
        return $r;
    }
    public function NumReportes($cc){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.Fecha,tipoactivo.Nombre,reporte.IdReporte from reporte join tipoactivo on reporte.TipoEquipo=tipoactivo.IdTipoActivo where CC = $cc");
        return $r;
    }
    public function VerRerporte($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.IdReporte,tipoactivo.Nombre,reporte.Num_Equipo,reporte.Ambiente,reporte.falla,reporte.CC,reporte.Fecha,estadorerporte.Nombre,reporte.EstadoReporte FROM reporte join tipoactivo on tipoactivo.IdTipoActivo = reporte.TipoEquipo join estadorerporte on estadorerporte.Id = reporte.EstadoReporte where IdReporte = $id ");
        return $r;
    }
    public function verChat($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT id_chat FROM chats where Id_Reporte = $id");
        return $r;
    }
    public function VerTodosReportesID($ID){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.IdReporte,tipoactivo.Nombre,reporte.Ambiente,reporte.Fecha,chats.id_chat,estadorerporte.Nombre,reporte.CC FROM reporte join tipoactivo on reporte.TipoEquipo=tipoactivo.IdTipoActivo join chats on reporte.IdReporte=chats.Id_Reporte join estadorerporte on estadorerporte.Id = reporte.EstadoReporte where reporte.IdReporte LIKE '%$ID%' ORDER BY IdReporte desc");
        return $r;
    }
    public function VerTodosReportesTC($TC){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.IdReporte,tipoactivo.Nombre,reporte.Ambiente,reporte.Fecha,chats.id_chat,estadorerporte.Nombre,reporte.CC FROM reporte join tipoactivo on reporte.TipoEquipo=tipoactivo.IdTipoActivo join chats on reporte.IdReporte=chats.Id_Reporte join estadorerporte on estadorerporte.Id = reporte.EstadoReporte where reporte.TipoEquipo LIKE '%$TC%' ORDER BY IdReporte desc");
        return $r;
    }
    public function VerTodosReportesA($A){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.IdReporte,tipoactivo.Nombre,reporte.Ambiente,reporte.Fecha,chats.id_chat,estadorerporte.Nombre,reporte.CC FROM reporte join tipoactivo on reporte.TipoEquipo=tipoactivo.IdTipoActivo join chats on reporte.IdReporte=chats.Id_Reporte join estadorerporte on estadorerporte.Id = reporte.EstadoReporte where reporte.Ambiente LIKE '%$A%' ORDER BY IdReporte desc");
        return $r;
    }
    public function VerTodosReportesF($F){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT reporte.IdReporte,tipoactivo.Nombre,reporte.Ambiente,reporte.Fecha,chats.id_chat,estadorerporte.Nombre,reporte.CC FROM reporte join tipoactivo on reporte.TipoEquipo=tipoactivo.IdTipoActivo join chats on reporte.IdReporte=chats.Id_Reporte join estadorerporte on estadorerporte.Id = reporte.EstadoReporte where reporte.Fecha LIKE '%$F%' ORDER BY IdReporte desc");
        return $r;
    }
}
class Activos{
    public function VerActivoPorID($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT activo.id,tipoactivo.Nombre,estadoactivo.NombreEstado,activo.Fecha_Ingreso,tipoactivo.imagen from activo join tipoactivo on tipoactivo.IdTipoActivo = activo.Tipo_Activo join estadoactivo on activo.Estado_Activo = estadoactivo.IdEstado where id = $id");
        return $r;
    }
    public function verActivosIndex(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $pila = array();
        $r =  mysqli_query($conexion,"SELECT * from activo where Estado_Activo = 1");
        $n = $r->num_rows;
        array_push($pila,$n);
        $r1 =  mysqli_query($conexion,"SELECT * from activo where Estado_Activo = 2");
        $n1 = $r1->num_rows;
        array_push($pila,$n1);
        return $pila;
    }
    public function Imagen($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT Imagen from activo where id = ".$id."");
        return $r;
    }
    public function Activos1(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * from activo");
        return $r;
    }
    public function VerActivos($n){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $n = $n * 3;
        $r =  mysqli_query($conexion,"SELECT activo.id,tipoactivo.Nombre,estadoactivo.NombreEstado,activo.Fecha_Ingreso,tipoactivo.imagen from activo join tipoactivo on tipoactivo.IdTipoActivo = activo.Tipo_Activo join estadoactivo on activo.Estado_Activo = estadoactivo.IdEstado LIMIT 3 OFFSET ".$n."");
        return $r;
    }
    public function AgregarActivo(ActivosM $M){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $fecha = $M->getFecha_Ingreso();
        $r =  mysqli_query($conexion,"INSERT INTO activo (id,Tipo_Activo,Estado_Activo,Fecha_Ingreso) VALUES (".$M->getId().",".$M->getTipoEquipo().",".$M->getEstadoEquipo().",'$fecha')");
        return $r;
    }
    public function AgregarModificacion(ActivosM $M){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $fecha = date('Y/m/d');
        switch ($M->getModificacion()) {
            case 1:
                $r =  mysqli_query($conexion,"INSERT INTO hoja_vida_activo (IdActivo,Tipo_Accion,Fecha,CC_Tecnico) values (".$M->getId().",".$M->getModificacion().",'".$fecha."',".$M->getCC().")");
                return $r;    
            break;
            case 2:
                $r =  mysqli_query($conexion,"INSERT INTO hoja_vida_activo (IdActivo,Tipo_Accion,Fecha,CC_Tecnico,Ambiente) values (".$M->getId().",".$M->getModificacion().",'".$fecha."',".$M->getCC().",".$M->getAmbiente().")");
                return $r;    
            break;
            case 3:
                $r =  mysqli_query($conexion,"INSERT INTO hoja_vida_activo (IdActivo,Tipo_Accion,Fecha,CC_Tecnico,Ambiente,CC_Persona) values (".$M->getId().",".$M->getModificacion().",'".$fecha."',".$M->getCC().",".$M->getAmbiente().",".$M->getCCAprendiz().")");
                return $r;
                break;
            default:
                # code...
                break;
        }
        return false;
    }
    public function Ambientes(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * FROM ambiente");
        return $r;
    }
    public function HojaVida($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT hoja_vida_activo.id,tipo_modificacion.Nombre,hoja_vida_activo.Fecha,hoja_vida_activo.Ambiente,hoja_vida_activo.CC_Tecnico,hoja_vida_activo.CC_Persona FROM hoja_vida_activo join tipo_modificacion on hoja_vida_activo.Tipo_Accion = tipo_modificacion.id where IdActivo = ".$id."");
        return $r;
    }
}
class Notificaciones{
    public function InsertarN($cc,$nombre){
        $id;
        $fecha = date('Y/m/d'); 
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r1 =  mysqli_query($conexion,"SELECT CC FROM reporte where IdReporte = ".$cc."");
        while($ver=mysqli_fetch_row($r1)){
            $id = $ver[0];
        }
        $r =  mysqli_query($conexion,"INSERT INTO notificaciones (nombre,fecha,visto,CC) VALUE ('".$nombre."','".$fecha."',1,".$id.")");
        return $r;
    }   
    public function InsertarNL($nombre){
        $fecha = date('Y/m/d'); 
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"INSERT INTO notificaciones (nombre,fecha,visto) VALUE ('".$nombre."','".$fecha."',1)");
        return $r;
    }
    public function seleccionar($cc){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * FROM notificaciones where CC = ".$cc." AND visto = 1");
        return $r;
    }
    public function seleccionar2(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT * FROM notificaciones where CC IS NULL AND visto = 1");
        return $r;
    }
    public function Visto($id){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"UPDATE notificaciones SET visto = 2 where id = $id");
        return $r;
    }

}
class corre {
    public function seleccionar(){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $r =  mysqli_query($conexion,"SELECT usuario FROM usuarios");
        return $r;
    }
    public function cambiarcontra($user,$pass){
        $conn = new Conexionbasedatos();
        $conexion = $conn ->Conect();
        $pasmd5 = md5($pass);
        $r =  mysqli_query($conexion,"UPDATE usuarios SET contrasena = '$pasmd5' where usuario = '$user'");
        return $r;
    }
}
?> 