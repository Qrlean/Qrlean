<?php
    header("location: index");
?>