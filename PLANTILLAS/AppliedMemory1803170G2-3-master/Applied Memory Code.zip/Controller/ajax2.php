<div id="mensajeria" class="mensajeria animated faster">
    <div class="padding">
            <div class="Chat ml-4">
                    <div class="header">
                        <header >DYLAN SNEIDER SANCHEZ ROJAS <br> / Piso 3 / Ambiente 307</header>
                        <button onClick="Cancelar2()" class="btn btn-danger">VOLVER</button>
                    </div>
                    <div id="MostrarChat" class="main mt-1 mb-1">
                    
                    </div>
                    <div class="footer">
                    <input id="mensaje" class="text" type="text"><img id="enviar" onClick="name()" src="Css/Img/communications.png" alt="">
                    </div>
            </div>
</div>
<?php
include_once("../Conexion/conexion.php");
$conn = new Conexionbasedatos();
$conexion = $conn ->Conect();
$cadena = "<div class='mensajes'>";
if(isset($_POST["chatAver"])){
    $id = $_POST["chatAver"];
    $cc = $_POST["CC"];
    $respuesta =  mysqli_query($conexion,"SELECT * from mensajes where Id_Chat = $id ORDER BY Fecha ASC, Hora ASC");
    while($ver=mysqli_fetch_row($respuesta)){
        $QUIEN = $ver[2];
        if($QUIEN==$cc){
            $cadena=$cadena."<div class='mensajeYo mt-1'>".$ver[1]."</div>";
        }
        else{
            $cadena=$cadena."<div class='mensajeOtro mt-1'>".$ver[1]."</div>";
        }
    }

        $cadena=$cadena."<input id='chat' type='hidden' value='$id'>";
}
echo $cadena."</div>";
?>