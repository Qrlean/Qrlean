<?php
if(isset($_POST["VerRe"])){
    include_once ("../Model/dao.php");
    $dao = new chat();
    $r = $dao->Chats();
    $dao1 = new ReporteD();
    $ID=$_POST["VerRe"];
    if(isset($_POST["OPCION"])){
        switch ($_POST["OPCION"]) {
            case 1:
                if(ctype_space($_POST["VerRe"])){
                    $r1 = $dao1->VerTodosReportesID('');
                    while($ver=mysqli_fetch_row($r1)){
                        echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                        <td style="width:10%">'.$ver[0].'</td>
                        <td style="width:20%">'.$ver[5].'</td>
                        <td style="width:20%">'.$ver[6].'</td>
                        <td style="width:20%">'.$ver[1].'</td>
                        <td style="width:10%">'.$ver[2].'</td>
                        <td style="width:20%">'.$ver[3].'</td>
                        </tr>';
                    }   
                }
                else{
                    $ID = trim($ID);
                    $r1 = $dao1->VerTodosReportesID($ID);
                    while($ver=mysqli_fetch_row($r1)){
                        echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                        <td style="width:10%">'.$ver[0].'</td>
                        <td style="width:20%">'.$ver[5].'</td>
                        <td style="width:20%">'.$ver[6].'</td>
                        <td style="width:20%">'.$ver[1].'</td>
                        <td style="width:10%">'.$ver[2].'</td>
                        <td style="width:20%">'.$ver[3].'</td>
                        </tr>';
                    }   
                }
                break;
                case 2:
                    if(ctype_space($_POST["VerRe"])){
                        $r1 = $dao1->VerTodosReportesTC('');
                        while($ver=mysqli_fetch_row($r1)){
                            echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                            <td style="width:10%">'.$ver[0].'</td>
                            <td style="width:20%">'.$ver[5].'</td>
                            <td style="width:20%">'.$ver[6].'</td>
                            <td style="width:20%">'.$ver[1].'</td>
                            <td style="width:10%">'.$ver[2].'</td>
                            <td style="width:20%">'.$ver[3].'</td>
                            </tr>';
                        }   
                    }
                    else{
                        $ID = trim($ID);
                        $r1 = $dao1->VerTodosReportesTC($ID);
                        while($ver=mysqli_fetch_row($r1)){
                            echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                            <td style="width:10%">'.$ver[0].'</td>
                            <td style="width:20%">'.$ver[5].'</td>
                            <td style="width:20%">'.$ver[6].'</td>
                            <td style="width:20%">'.$ver[1].'</td>
                            <td style="width:10%">'.$ver[2].'</td>
                            <td style="width:20%">'.$ver[3].'</td>
                            </tr>';
                        }   
                    }
                    break;
                    case 3:
                        if(ctype_space($_POST["VerRe"])){
                            $r1 = $dao1->VerTodosReportesA('');
                            while($ver=mysqli_fetch_row($r1)){
                                echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                                <td style="width:10%">'.$ver[0].'</td>
                                <td style="width:20%">'.$ver[5].'</td>
                                <td style="width:20%">'.$ver[6].'</td>
                                <td style="width:20%">'.$ver[1].'</td>
                                <td style="width:10%">'.$ver[2].'</td>
                                <td style="width:20%">'.$ver[3].'</td>
                                </tr>';
                            }   
                        }
                        else{
                            $ID = trim($ID);
                            $r1 = $dao1->VerTodosReportesA($ID);
                            while($ver=mysqli_fetch_row($r1)){
                                echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                                <td style="width:10%">'.$ver[0].'</td>
                                <td style="width:20%">'.$ver[5].'</td>
                                <td style="width:20%">'.$ver[6].'</td>
                                <td style="width:20%">'.$ver[1].'</td>
                                <td style="width:10%">'.$ver[2].'</td>
                                <td style="width:20%">'.$ver[3].'</td>
                                </tr>';
                            }   
                        }
                        break;
                        case 4:
                            if(ctype_space($_POST["VerRe"])){
                                $r1 = $dao1->VerTodosReportesF('');
                                while($ver=mysqli_fetch_row($r1)){
                                    echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                                    <td style="width:10%">'.$ver[0].'</td>
                                    <td style="width:20%">'.$ver[5].'</td>
                                    <td style="width:20%">'.$ver[6].'</td>
                                    <td style="width:20%">'.$ver[1].'</td>
                                    <td style="width:10%">'.$ver[2].'</td>
                                    <td style="width:20%">'.$ver[3].'</td>
                                    </tr>';
                                }   
                            }
                            else{
                                $ID = trim($ID);
                                $r1 = $dao1->VerTodosReportesF($ID);
                                while($ver=mysqli_fetch_row($r1)){
                                    echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                                    <td style="width:10%">'.$ver[0].'</td>
                                    <td style="width:20%">'.$ver[5].'</td>
                                    <td style="width:20%">'.$ver[6].'</td>
                                    <td style="width:20%">'.$ver[1].'</td>
                                    <td style="width:10%">'.$ver[2].'</td>
                                    <td style="width:20%">'.$ver[3].'</td>
                                    </tr>';
                                }   
                            }
                            break;
            default:
            $r1 = $dao1->VerTodosReportesID('');
            while($ver=mysqli_fetch_row($r1)){
                echo '<tr onClick=" VerReporte('.$ver[0].')" class="lP">
                <td style="width:10%"  class="lP">'.$ver[0].'</td>
                <td style="width:20%"  class="lP">'.$ver[5].'</td>
                <td style="width:20%">'.$ver[6].'</td>
                <td style="width:20%">'.$ver[1].'</td>
                <td style="width:10%">'.$ver[2].'</td>
                <td style="width:20%">'.$ver[3].'</td>
                </tr>';
            }  
                break;
        }
    }
}
?>