<?php
if(isset($_POST["TiDo"])&&isset($_POST["CC"])&&isset($_POST["Nombre"])&&isset($_POST["Apelli"])&&isset($_POST["Correo"])&&isset($_POST["Pass"])&&isset($_POST["TipoCuenta"])){
    include_once("../Model/dao.php");
    $c = new registrar();
    $r=$c->InsertarDatos($_POST["CC"],$_POST["Nombre"],$_POST["Apelli"],$_POST["TiDo"]);
    if($r){
        $r1=$c->InsertarCuenta($_POST["CC"],$_POST["Correo"],$_POST["Pass"],$_POST["TipoCuenta"]);
        if($r1){
            header("location : ../Registrar?O=1");
        }else{
            header("location : ../Registrar?O=2");
        }
    }else{
        header("location : ../Registrar?O=2");
    }
}else{
    header("location : Registrar?O=3");
}
?>