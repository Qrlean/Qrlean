<?php
include_once("../Conexion/conexion.php");
$conn = new Conexionbasedatos();
$conexion = $conn ->Conect();
if(isset($_POST["mensaje"])){
    $mensaje = $_POST["mensaje"];
    $id = $_POST["id"];
    $Cc = $_POST["CC"];
    date_default_timezone_set("America/Bogota");
    $fecha = date('Y/m/d');
    $Hora = date('H:i:s');
    if($mensaje==""){
    }else{
        $r =  mysqli_query($conexion,"INSERT INTO mensajes (Mensaje,CC_T,Fecha,Id_Chat,Hora) VALUES ('$mensaje',$Cc,'$fecha',$id,'$Hora')");
    }
}
?>