<?php
if(isset($_POST["TipoEquipo"])&&isset($_POST["Ambiente"])&&isset($_POST["NumEquipo"])&&isset($_POST["Mensaje"])&&isset($_POST["CC"])){
    include_once("../Model/Model.php");
    include_once("../Model/dao.php");
    $dao1 = new Notificaciones();
    $dao = new ReporteD();
    $model = new Reporte();
    $model->setCC($_POST["CC"]);
    $model->setTipoEquipo($_POST["TipoEquipo"]);
    $model->setAmbiente($_POST["Ambiente"]);
    $model->setNum_Equipo($_POST["NumEquipo"]);
    $model->setMensaje($_POST["Mensaje"]);
    $r1 = $dao->RegistrarReporte($model);
    $dao->CrearChat($model->getCC());
    if($r1){
        header('Location: ../Reporte?M='.urlencode(1));
        $R = $dao1->InsertarNL("NUEVO REPORTE");
    } 
    else {
        header('Location: ../Reporte?M='.urlencode(2));
    }    
}
else{
    header('Location: ../');
}
?>
