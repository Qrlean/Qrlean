<?php include_once('../config.php')?>
<?php
echo '<tr class="N_Activo animated faster ">
<td style="width:20%"><input style="text-align:center" placeholder="ID EQUIPO" class="Id" name="" id=""></td>
<td style="width:20%">
    <select  id="lista1" class="TipoActivo select" name="TipoEquipo"  required>
    <option hidden selected>SELECCIONA EQUIPO</option>';
        require_once("../Model/dao.php");
        $c = new ReporteD();
        $r = $c->EquipoaRerportar();
        while($clientes=mysqli_fetch_row($r))
        {   
            echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
        } 
    echo '</select>
</td>
<td style="width:20%">
    <select  id="lista1" class="Accion select" name="TipoEquipo"  required>
    <option hidden selected>ACCION</option>';
        require_once("../Model/dao.php");
        $c = new ReporteD();
        $r = $c->TipoAccion();
        while($clientes=mysqli_fetch_row($r))
        {   
            echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
        } 
    echo '</select>
</td>
<td style="width:20%">
    <select  id="lista1" class="EstadoActivo select" name="TipoEquipo"  required>
    <option disabled>ESTADO ACTIVO</option>';
        require_once("../Model/dao.php");
        $c = new ReporteD();
        $r = $c->EstadoActivo();
        while($clientes=mysqli_fetch_row($r))
        {   
            echo "<option  value='".$clientes[0]."'>".$clientes[1]."</option>";  
        } 
    echo '</select>
</td>';
$fcha = date("Y-m-d");
echo '<td style="width:20%"><input class="Fecha" type="date" name="" value="'.$fcha.'" id=""></td>
</tr>';
?>