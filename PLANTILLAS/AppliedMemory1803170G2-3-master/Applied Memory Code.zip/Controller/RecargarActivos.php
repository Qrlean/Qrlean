<?php
            include_once ("../Model/dao.php");
            $dao = new Activos();
            $r = $dao->VerActivos($_POST["n"]);
            while($ver=mysqli_fetch_row($r)){
                echo   '<form action="HojaVida" method="POST"><button type="submit" class="activoM">
                <div style="width:40%;float:left;padding:4px;">
                <h5 style="text-align:center">'.$ver[1].'</h5>
                <img style="display:block;margin:auto;width:80%;" src="Css/Img/'.$ver[4].'">
                </div>
                <div style="width:60%;float:left;padding:10px">
                <h5>ID : '.$ver[0].'</h5>
                <h5>Estado : '.$ver[2].'</h5>
                <h5>Fecha : '.$ver[3].'</h5>
                <input type="hidden" name="ID" value="'.$ver[0].'">
                </div>
            </button></form>';
            }
?>