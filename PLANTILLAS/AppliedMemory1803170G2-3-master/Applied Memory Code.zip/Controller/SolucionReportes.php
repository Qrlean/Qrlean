<?php
include_once("../Model/dao.php");
$dao = new ReporteD();
if(isset($_POST["Id"])&&isset($_POST["Estado"])){
    $R = $dao-> EstadoReporte($_POST["Id"],$_POST["Estado"]);
}
?>