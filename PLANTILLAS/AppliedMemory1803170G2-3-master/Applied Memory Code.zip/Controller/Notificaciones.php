<?php
include_once("../Model/dao.php");
$dao = new Notificaciones();
if(isset($_POST["Id"])&&isset($_POST["Mensaje"])){
    $R = $dao->  InsertarN($_POST["Id"],$_POST["Mensaje"]);
}
if(isset($_POST["Visto"])){
    $R = $dao->Visto($_POST["Visto"]);
}
?>