<?php
if(isset($_POST["user"])&&isset($_POST["pass"])){
    include_once("../Model/dao.php");
    $dao = new corre();
    $r = $dao->cambiarcontra($_POST["user"],$_POST["pass"]);
    if($r){
        echo "cambiada";
    }else{
        echo "no cambiada";
    }
}
else{
    echo "no";
}
?>