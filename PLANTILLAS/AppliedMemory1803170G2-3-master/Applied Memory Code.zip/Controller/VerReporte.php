<?php
include_once("../Model/dao.php");
$dao = new ReporteD();
if(isset($_POST["IdMensaje"])){
    $id = $_POST["IdMensaje"];
    $cc = $_POST["CC"];
    $r = $dao->VerRerporte($id);
    while($clientes=mysqli_fetch_row($r))
    {   
        $IdReporte=$clientes[0];
        $r1 = $dao->verChat($IdReporte);
        $IdChat;
        while($clientes1=mysqli_fetch_row($r1)){
            $IdChat = $clientes1[0];
        }
        echo '
        <div class="HeaderR row">
        <h5 class="col-6">REPORTE #'.$clientes[0].'</h5>
        <h5 class="col-6">Fecha : '.$clientes[6].'</h5>
        </div>
        <div class="MainR">
        <div class="info row">
            <h5 class="col-6 ">Equipo Reportado</h5>
            <h5 class="col-6 ">'.$clientes[1].'</h5>
        </div>
        <div class="info row">
            <h5 class="col-6 ">Ambiente</h5>
            <h5 class="col-6 ">'.$clientes[3].'</h5>
        </div>
        <div class="info row">
            <h5 class="col-6 ">Numero Equipo</h5>
            <h5 class="col-6 ">'.$clientes[2].'</h5>
        </div>
        <div class="info row">
            <h5 class="col-6">Mensaje</h5>
            <h5 class="col-6">'.$clientes[4].'</h5>
        </div>';
        if($clientes[8]=="3"){
            echo '<input type="hidden" id="solucionar-chat" value="1">';
        }
        if($clientes[8]=="1"){
            echo '<input type="hidden" id="solucionar-chat" value="3">';
        }
        if($clientes[8]=="2"){
            echo '<input type="hidden" id="solucionar-chat" value="2">';
        }

    } 
}
?>