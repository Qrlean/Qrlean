<?php
include_once("../Model/user_session.php");
include_once("../Model/dao.php");
$dao = new Perfil();
$userSession = new UserSession();
$dao -> EstadoLinea(2,$_SESSION["user"]);
$userSession->closeSession();
if($userSession){
    header("location: ../");
}else{
    header("location: ../");
}
?>