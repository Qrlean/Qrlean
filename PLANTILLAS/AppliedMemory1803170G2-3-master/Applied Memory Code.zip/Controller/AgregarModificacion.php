<?php
include_once("../Model/Model.php");
include_once("../Model/dao.php");
$dao = new Activos();
$model = new ActivosM();
if(isset($_POST["Accion"])&&isset($_POST["EstadoActivo"])&&isset($_POST["ID"])){
    $model->setId($_POST["ID"]);
    $model->setEstadoEquipo($_POST["EstadoActivo"]);
    $model->setModificacion($_POST["Accion"]);
    $model->setCC($_POST["CC"]);
    if($_POST["Ambiente"]!= 'AMBIENTE'){
        $model->setAmbiente($_POST["Ambiente"]);
    }
    if($_POST["CC_Aprendiz"]!=''){
        $model->setCCAprendiz($_POST["CC_Aprendiz"]);
    }
    $r = $dao->AgregarModificacion($model);
    if($r){
        echo '<script language="javascript">alert("MODIFICACION REALIZADA CON EXITO");</script>';
    }else{
        echo '<script language="javascript">alert("ERROR AL REALIZAR LA MODIFICACION");</script>';
    }
}else{
}
?>