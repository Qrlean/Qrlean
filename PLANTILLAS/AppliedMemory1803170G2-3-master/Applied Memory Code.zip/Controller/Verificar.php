<?php
include_once("../Model/user_session.php");
include_once("../Model/User.php");
include_once("../Model/dao.php");
$dao = new Perfil();
$user = new User();
$userSession = new UserSession();
if(isset($_SESSION["user"])){
    header("location: ../ "); 
}else if(isset($_POST['username']) && isset($_POST["password"])){
    $userForm = $_POST["username"];
    $passForm = $_POST["password"];
    if($user->userExists($userForm,$passForm)){
        $cc = $user->getCc();
        $Rol = $user->getRol();
        $userSession->setCurrentUser($cc);
        $userSession->setCurrentRol($Rol);
        $userSession->setCurrentEstado(1);
        $dao -> EstadoLinea(1,$cc);
        header("location: ../");
    }
    else {
        $erroLogin = "Nombre de Usuario y/o Password es incorrecto";
        $userSession->closeSession();
        header("location: ../Login?E");
    }
}
else {
    header("location: ../Login");
}
?>