<?php
include_once("../Model/Model.php");
include_once("../Model/dao.php");
$dao = new Activos();
$model = new ActivosM();
if($_POST["Id"]!='' && isset($_POST["TipoEquipo"]) && isset($_POST["EA"]) && isset($_POST["FI"])){
    $id = $_POST["Id"];
    $model->setid($_POST["Id"]);
    $model->setTipoEquipo($_POST["TipoEquipo"]);
    $model->setEstadoEquipo($_POST["EA"]);
    $model->setFecha_Ingreso($_POST["FI"]);
    $r = $dao->AgregarActivo($model);
    if($r){
        echo   '<tr class="fadeInLeft animated faster delay-1s  Errores" style="background-color: rgba(9, 255, 0, 0.6); border:5px solid white;">
        <td style="padding:10px">ACTIVO #'.$id.' AGREGADO CORRECTAMENTE</td>
        </tr>';
    }
    else{
        echo   '<tr class="fadeInLeft animated faster delay-1s  Errores" style="background-color: rgba(255, 0, 0, 0.6); border:5px solid white;">
        <td style="padding:10px">No se pudo agregar el activo #'.$id.'</td>
        </tr>';
    }
}
else{
    echo '<tr class="fadeInLeft  animated faster delay-1s  Errores " style="background-color: rgba(255, 0, 0, 0.6); border:5px solid white;">
    <td style="padding:10px;">POR FAVOR INGRESE TODOS LOS DATOS</td>
</tr>';
}
?>