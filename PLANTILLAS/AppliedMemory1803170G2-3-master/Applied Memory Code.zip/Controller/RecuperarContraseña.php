<?php
if(isset($_POST["email"])){
    include_once("../Model/dao.php");
    $dao = new corre();
    $r = $dao->seleccionar();
    while($ver=mysqli_fetch_row($r)){
        if($ver[0]==$_POST["email"]){
            echo "1";
        }
    }
}
?>