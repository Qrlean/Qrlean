<?php
const SERVERURL = "https://smwjvhak.lucusvirtual.es/"
?>